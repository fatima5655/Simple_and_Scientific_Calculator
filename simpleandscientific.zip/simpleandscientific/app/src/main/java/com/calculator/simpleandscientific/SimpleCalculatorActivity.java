package com.calculator.simpleandscientific;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class SimpleCalculatorActivity extends AppCompatActivity {

    private EditText inputField;
    private String currentInput = "";
    private boolean lastNumeric = false;
    private boolean lastDot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simple_calculator);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Initialize the input field
        inputField = findViewById(R.id.inputField);
        inputField.setShowSoftInputOnFocus(false); // Disable keyboard popup

        // Set click listeners for buttons
        int[] numberButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(this::onNumberClick);
        }

        findViewById(R.id.btnDecimal).setOnClickListener(this::onDecimalClick);
        findViewById(R.id.btnAdd).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnSubtract).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnMultiply).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnDivide).setOnClickListener(this::onOperatorClick);
        findViewById(R.id.btnEquals).setOnClickListener(this::onEqualsClick);
        findViewById(R.id.btnAC).setOnClickListener(this::onClearClick);
        findViewById(R.id.btnPercent).setOnClickListener(this::onPercentClick);
    }

    // Handle number button clicks
    private void onNumberClick(View view) {
        Button button = (Button) view;
        currentInput += button.getText().toString();
        inputField.setText(currentInput);
        lastNumeric = true;
    }

    // Handle decimal button click
    private void onDecimalClick(View view) {
        if (lastNumeric && !lastDot) {
            currentInput += ".";
            inputField.setText(currentInput);
            lastNumeric = false;
            lastDot = true;
        }
    }

    // Handle operator button clicks
    private void onOperatorClick(View view) {
        if (lastNumeric && !isOperatorAdded(currentInput)) {
            Button button = (Button) view;
            currentInput += " " + button.getText().toString() + " ";
            inputField.setText(currentInput);
            lastNumeric = false;
            lastDot = false;
        }
    }

    // Handle equals button click
    private void onEqualsClick(View view) {
        if (lastNumeric) {
            String result = evaluateExpression(currentInput);
            inputField.setText(result);
            currentInput = result;
            lastNumeric = true;
            lastDot = result.contains(".");
        }
    }

    // Handle clear button click
    private void onClearClick(View view) {
        currentInput = "";
        inputField.setText("");
        lastNumeric = false;
        lastDot = false;
    }

    // Handle percent button click
    private void onPercentClick(View view) {
        if (lastNumeric) {
            double value = Double.parseDouble(currentInput);
            double percent = value / 100;
            currentInput = String.valueOf(percent);
            inputField.setText(currentInput);
            lastNumeric = true;
            lastDot = currentInput.contains(".");
        }
    }

    // Check if an operator is already added
    private boolean isOperatorAdded(String value) {
        return value.contains("+") || value.contains("-") || value.contains("×") || value.contains("÷");
    }

    // Evaluate the expression
    private String evaluateExpression(String expression) {
        try {
            // Replace × and ÷ with * and / for evaluation
            expression = expression.replace("×", "*").replace("÷", "/");

            // Evaluate the expression
            double result = eval(expression);
            return String.valueOf(result);
        } catch (Exception e) {
            return "Error";
        }
    }

    // Evaluate mathematical expressions
    private double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Handle back button click
        onBackPressed();
        return true;
    }
}
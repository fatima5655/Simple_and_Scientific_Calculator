package com.calculator.simpleandscientific;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ScientificCalculatorActivity extends AppCompatActivity {

    private EditText inputFieldScientific;
    private String currentInput = "";
    private boolean lastNumeric = false;
    private boolean lastDot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scientific_calculator);

        // Set up the toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Initialize the input field
        inputFieldScientific = findViewById(R.id.inputFieldScientific);
        inputFieldScientific.setShowSoftInputOnFocus(false); // Disable keyboard popup

        // Number Buttons (0-9)
        int[] numberButtonIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        };
        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(this::onNumberClick);
        }

        // Operator Buttons (+, -, ×, ÷)
        int[] operatorButtonIds = {
                R.id.btnAdd, R.id.btnSubtract, R.id.btnMultiply, R.id.btnDivide
        };
        for (int id : operatorButtonIds) {
            findViewById(id).setOnClickListener(this::onOperatorClick);
        }

        // Advanced Function Buttons
        findViewById(R.id.btnSin).setOnClickListener(v -> onFunctionClick("sin("));
        findViewById(R.id.btnCos).setOnClickListener(v -> onFunctionClick("cos("));
        findViewById(R.id.btnTan).setOnClickListener(v -> onFunctionClick("tan("));
        findViewById(R.id.btnLog).setOnClickListener(v -> onFunctionClick("log("));
        findViewById(R.id.btnLn).setOnClickListener(v -> onFunctionClick("ln("));
        findViewById(R.id.btnSqrt).setOnClickListener(v -> onFunctionClick("√("));
        findViewById(R.id.btnSquare).setOnClickListener(v -> onFunctionClick("^2"));
        findViewById(R.id.btnPower).setOnClickListener(v -> onFunctionClick("^"));
        findViewById(R.id.btnReciprocal).setOnClickListener(v -> onFunctionClick("1/"));
        findViewById(R.id.btnFactorial).setOnClickListener(v -> onFunctionClick("!"));
        findViewById(R.id.btnPi).setOnClickListener(v -> onFunctionClick("π"));
        findViewById(R.id.btnE).setOnClickListener(v -> onFunctionClick("e"));
        findViewById(R.id.btnOpenBracket).setOnClickListener(v -> onFunctionClick("("));
        findViewById(R.id.btnCloseBracket).setOnClickListener(v -> onFunctionClick(")"));
        findViewById(R.id.btnPercent).setOnClickListener(v -> onFunctionClick("%"));

        // Decimal Button
       // findViewById(R.id.btnDecimal).setOnClickListener(this::onDecimalClick);

        // Equals Button
        findViewById(R.id.btnEquals).setOnClickListener(this::onEqualsClick);

        // Clear Button
        findViewById(R.id.btnClear).setOnClickListener(this::onClearClick);
    }

    // Handle number button clicks
    private void onNumberClick(View view) {
        Button button = (Button) view;
        currentInput += button.getText().toString();
        inputFieldScientific.setText(currentInput);
        lastNumeric = true;
    }

    // Handle operator button clicks
    private void onOperatorClick(View view) {
        if (lastNumeric && !isOperatorAdded(currentInput)) {
            Button button = (Button) view;
            currentInput += " " + button.getText().toString() + " ";
            inputFieldScientific.setText(currentInput);
            lastNumeric = false;
            lastDot = false;
        }
    }

    // Handle advanced function button clicks
    private void onFunctionClick(String function) {
        if (function.equals("log(") || function.equals("ln(")) {
            // For log and ln, ensure the input is a number
            if (lastNumeric) {
                currentInput += function;
                inputFieldScientific.setText(currentInput);
                lastNumeric = false;
                lastDot = false;
            }
        } else {
            // For other functions like sin, cos, tan, etc.
            currentInput += function;
            inputFieldScientific.setText(currentInput);
            lastNumeric = false;
            lastDot = false;
        }
    }

    // Handle decimal button click
    private void onDecimalClick(View view) {
        if (lastNumeric && !lastDot) {
            currentInput += ".";
            inputFieldScientific.setText(currentInput);
            lastNumeric = false;
            lastDot = true;
        }
    }

    // Handle equals button click
    private void onEqualsClick(View view) {
        if (lastNumeric) {
            String result = evaluateExpression(currentInput);
            inputFieldScientific.setText(result);
            currentInput = result;
            lastNumeric = true;
            lastDot = result.contains(".");
        }
    }

    // Handle clear (C) button click
    private void onClearClick(View view) {
        currentInput = "";
        inputFieldScientific.setText("");
        lastNumeric = false;
        lastDot = false;
    }

    // Check if an operator is already added
    private boolean isOperatorAdded(String value) {
        return value.contains("+") || value.contains("-") || value.contains("×") || value.contains("÷");
    }

    // Evaluate the expression
    private String evaluateExpression(String expression) {
        try {
            // Replace advanced functions with their mathematical equivalents
            expression = expression.replace("sin(", "Math.sin(Math.toRadians(")
                    .replace("cos(", "Math.cos(Math.toRadians(")
                    .replace("tan(", "Math.tan(Math.toRadians(")
                    .replace("log(", "Math.log10(")
                    .replace("ln(", "Math.log(")
                    .replace("√(", "Math.sqrt(")
                    .replace("^2", "*" + expression.substring(expression.indexOf("^2") - 1, expression.indexOf("^2")) + ")")
                    .replace("π", String.valueOf(Math.PI))
                    .replace("e", String.valueOf(Math.E))
                    .replace("%", "/100");

            // Replace × and ÷ with * and / for evaluation
            expression = expression.replace("×", "*").replace("÷", "/");

            // Evaluate the expression
            double result = eval(expression);
            return String.valueOf(result);
        } catch (Exception e) {
            Log.e("ScientificCalculator", "Error evaluating expression: " + e.getMessage());
            return "Error";
        }
    }

    // Evaluate mathematical expressions
    private double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (; ; ) {
                    if (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (; ; ) {
                    if (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }

    @Override
    public boolean onSupportNavigateUp() {
        // Handle back button click
        onBackPressed();
        return true;
    }
}
package com.calculator.simpleandscientific;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Remove default title (if any)
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // Initialize buttons
        Button btnSimpleCalculator = findViewById(R.id.btnSimpleCalculator);
        Button btnScientificCalculator = findViewById(R.id.btnScientificCalculator);


        // Set click listeners
        btnSimpleCalculator.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SimpleCalculatorActivity.class);
            startActivity(intent);
        });

        btnScientificCalculator.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ScientificCalculatorActivity.class);
            startActivity(intent);
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Handle action bar item clicks here.
        int id = item.getItemId();

        if (id == R.id.action_privacy_policy) {
            // Open Privacy Policy (e.g., a web page or a new activity)
            openPrivacyPolicy();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void openPrivacyPolicy() {
        // Example: Open a web page with the privacy policy
        String url = "https://qualitysol.site/privacy-policy/";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}